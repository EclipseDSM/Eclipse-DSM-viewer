package org.dtangler.core.dependencyengine;

public class DependencyEnginePoolConfigConstants {

	public static final String ID_DEFAULT_DEPENDENCY_ENGINE_KEY = "defaultDependencyEngineId";

	public static final String[] VALID_KEYS = { ID_DEFAULT_DEPENDENCY_ENGINE_KEY };

}
