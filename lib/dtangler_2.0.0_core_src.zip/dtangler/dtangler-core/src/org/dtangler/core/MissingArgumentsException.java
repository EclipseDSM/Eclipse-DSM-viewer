package org.dtangler.core;

public class MissingArgumentsException extends RuntimeException {

}
